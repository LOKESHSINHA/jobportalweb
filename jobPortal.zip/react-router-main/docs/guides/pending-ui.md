---
title: Pending UI
hidden: true
---

# Pending UI

React Router has APIs to help you build the user experience you're after when asynchronous things are happening with:

- [useNavigation][use-navigation]
- [useFetcher][use-navigation]
- [Outlet][outlet]
