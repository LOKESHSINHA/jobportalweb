# React Router DOM

The `react-router-dom` package contains bindings for using [React
Router](https://github.com/remix-run/react-router) in web applications.
Please see [the Getting Started guide](https://reactrouter.com/en/main/start/tutorial) for more information on how to get started with React Router.
