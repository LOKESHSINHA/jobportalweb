# React Router Native

The `react-router-native` package contains bindings for using [React
Router](https://github.com/remix-run/react-router) in [React
Native](https://facebook.github.io/react-native/) applications.
Please see [the Getting Started guide](https://reactrouter.com/en/main/start/tutorial) for more information on how to get started with React Router.
