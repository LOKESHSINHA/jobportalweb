/**
 * @type {import('prettier').Options}
 */
module.exports = {};
