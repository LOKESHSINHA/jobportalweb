import * as React from "react";
import * as ReactDOM from "react-dom";
import App from "./App";
import "./main.css";

let rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
