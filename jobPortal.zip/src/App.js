import React from 'react';
import './App.css';
import Navbar from './componant/Navbar';
import Background from './componant/Background ';
import JobDetails from './componant/JobDetails ';
import JobList from './componant/JobList ';
function App() {

  return (
    <>
      <Navbar />
      <Background/>
       <JobList/>
       <JobDetails/>
          </>
  );
}

export default App;

