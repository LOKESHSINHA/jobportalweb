import React, { useState } from 'react';

const JobList = () => {
  const [jobs, setJobs] = useState([
    {
      id: 1,
      title: 'Job 1',
      description: 'Description of Job 1',
      tags: ['tag1', 'tag2'],
      stipend: '$1000',
      duration: '3 months',
    },
    {
      id: 2,
      title: 'Job 2',
      description: 'Description of Job 2',
      tags: ['tag3', 'tag4'],
      stipend: '$1500',
      duration: '6 months',
    },
    {
      id: 3,
      title: 'Job 3',
      description: 'Description of Job 3',
      tags: ['tag3', 'tag4'],
      stipend: '$1500',
      duration: '6 months',
    }
    // Add more job objects as needed
  ]);

  const handleJobClick = (jobId) => {
    // Navigate to the job details page
  };

  return (
    <div>
      <h1>Job List</h1>
      <input type="text" placeholder="Search by name" />
      {/* Add filter options */}
      <ul>
        {jobs.map((job) => (
          <li key={job.id} onClick={() => handleJobClick(job.id)}>
            <h3>{job.title}</h3>
            <p>{job.description}</p>
            <p>Tags: {job.tags.join(', ')}</p>
            <p>Stipend: {job.stipend}</p>
            <p>Duration: {job.duration}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default JobList;
