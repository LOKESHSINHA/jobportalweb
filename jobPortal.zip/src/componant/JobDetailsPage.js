import React from 'react';
import { useParams } from 'react-router-dom';

const jobData = [
  {
    id: 1,
    title: 'Job 1',
    description: 'This is job 1',
    role: 'Job 1 role',
    responsibilities: 'Job 1 responsibilities',
  },
  {
    id: 2,
    title: 'Job 2',
    description: 'This is job 2',
    role: 'Job 2 role',
    responsibilities: 'Job 2 responsibilities',
  },
  // Add more job objects as needed
];

const JobDetailsPage = () => {
  const { jobId } = useParams();
  const job = jobData.find((job) => job.id === Number(jobId));

  if (!job) {
    return <div>Job not found.</div>;
  }

  return (
    <div>
      <h1>{job.title}</h1>
      <p>Description: {job.description}</p>
      <p>Role: {job.role}</p>
      <p>Responsibilities: {job.responsibilities}</p>
      <h2>Similar Jobs</h2>
      <ul>
        {jobData
          .filter((j) => j.title !== job.title)
          .map((j) => (
            <li key={j.id}>{j.title}</li>
          ))}
      </ul>
    </div>
  );
};

export default JobDetailsPage;
