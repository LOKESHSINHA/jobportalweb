import React from 'react';

class Background extends React.Component {
  state = {};

  render() {
    return (
      <div
        className="background-class"
        style={{
          backgroundColor: 'black',
          backgroundSize: 'cover'
        }}
      >
        {/* Your component's content */}
      </div>
    );
  }
}

export default Background;
