import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

const jobData = [
  {
    id: 1,
    title: 'Job 1',
    description: 'This is job 1',
    tags: ['tag1', 'tag2'],
    stipend: '$1000',
    duration: '3 months',
    date: '2023-06-01',
  },
  {
    id: 2,
    title: 'Job 2',
    description: 'This is job 2',
    tags: ['tag2', 'tag3'],
    stipend: '$1500',
    duration: '6 months',
    date: '2023-06-05',
  },
  // Add more job objects as needed
];

const JobListPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState('ascending');
  const history = useHistory();

  const handleJobClick = (jobId) => {
    history.push(`/job/${jobId}`);
  };

  const filteredJobs = jobData.filter((job) =>
    job.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedJobs = filteredJobs.sort((job1, job2) => {
    if (sortOrder === 'ascending') {
      return new Date(job1.date) - new Date(job2.date);
    } else {
      return new Date(job2.date) - new Date(job1.date);
    }
  });

  return (
    <div>
      <h1>Job List</h1>
      <input
        type="text"
        placeholder="Search by job name"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <select
        value={sortOrder}
        onChange={(e) => setSortOrder(e.target.value)}
      >
        <option value="ascending">Sort by date (ascending)</option>
        <option value="descending">Sort by date (descending)</option>
      </select>
      <ul>
        {sortedJobs.map((job) => (
          <li key={job.id} onClick={() => handleJobClick(job.id)}>
            <h3>{job.title}</h3>
            <p>{job.description}</p>
            <p>Tags: {job.tags.join(', ')}</p>
            <p>Stipend: {job.stipend}</p>
            <p>Duration: {job.duration}</p>
            <p>Date: {job.date}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default JobListPage;
